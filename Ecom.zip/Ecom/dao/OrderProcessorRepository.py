from abc import ABC, abstractmethod
from entity.customers import Customers
from entity.products import Products
from typing import List, Dict

class OrderProcessorRepository(ABC):

    @abstractmethod
    def create_product(self, product: Products) -> bool: pass

    @abstractmethod
    def create_customer(self, customer: Customers) -> bool: pass

    @abstractmethod
    def delete_product(self, product_id: int) -> bool: pass

    @abstractmethod
    def delete_customer(self, customer_id: int) -> bool: pass

    @abstractmethod
    def add_to_cart(self, customer: Customers, product: Products, quantity: int) -> bool: pass

    @abstractmethod
    def remove_from_cart(self, customer: Customers, product: Products) -> bool: pass

    @abstractmethod
    def get_all_from_cart(self, customer: Customers) -> List[Products]: pass

    @abstractmethod
    def place_order(self, customer: Customers, order_items: Dict[Products, int], shipping_address: str) -> bool: pass

    @abstractmethod
    def get_orders_by_customer(self, customer_id: int) -> List[Dict[Products, int]]: pass
