import pyodbc
from datetime import datetime
from entity.customers import Customers
from entity.products import Products
from myexceptions.CustomerNotFoundException import CustomerNotFoundException
from myexceptions.ProductNotFoundException import ProductNotFoundException
from myexceptions.OrderNotFoundException import OrderNotFoundException

class OrderProcessorRepositoryImpl:
    def __init__(self):
        self.conn = pyodbc.connect(
            'DRIVER={SQL Server};'
            'SERVER=DESKTOP-R30EJB7\SQLEXPRESS;'
            'DATABASE=ECom;'
            'Trusted_Connection=yes;'
        )
        self.cursor = self.conn.cursor()

    def create_customer(self, customer):
        try:
            self.cursor.execute("INSERT INTO customers (name, email, password) VALUES (?, ?, ?)",
                                customer.name, customer.email, customer.password)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error creating customer: {e}")
            return False

    def create_product(self, product):
        try:
            self.cursor.execute("INSERT INTO products (name, price, description, stockQuantity) VALUES (?, ?, ?, ?)",
                                product.name, product.price, product.description, product.stockQuantity)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error creating product: {e}")
            return False

    def delete_product(self, product_id):
        try:
            self.cursor.execute("DELETE FROM products WHERE product_id = ?", product_id)
            self.conn.commit()
            return self.cursor.rowcount > 0
        except Exception as e:
            print(f"Error deleting product: {e}")
            return False

    def add_to_cart(self, customer, product, quantity):
        try:
            # Check if customer exists
            self.cursor.execute("SELECT * FROM customers WHERE customer_id = ?", customer.customer_id)
            if not self.cursor.fetchone():
                raise CustomerNotFoundException("Customer not found")

            # Check if product exists
            self.cursor.execute("SELECT * FROM products WHERE product_id = ?", product.product_id)
            if not self.cursor.fetchone():
                raise ProductNotFoundException("Product not found")

            # Add to cart
            self.cursor.execute("INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)",
                                customer.customer_id, product.product_id, quantity)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error adding to cart: {e}")
            return False

    def get_all_from_cart(self, customer):
        try:
            self.cursor.execute("""
                SELECT p.name, p.price, p.description, c.quantity
                FROM cart c
                JOIN products p ON c.product_id = p.product_id
                WHERE c.customer_id = ?
            """, customer.customer_id)

            results = self.cursor.fetchall()
            return results
        except Exception as e:
            print(f"Error getting cart: {e}")
            return []

    def get_product_by_id(self, product_id):
        self.cursor.execute("SELECT * FROM products WHERE product_id = ?", product_id)
        row = self.cursor.fetchone()
        if row:
            return Products(product_id=row[0], name=row[1], price=row[2], description=row[3], stockQuantity=row[4])
        else:
            raise ProductNotFoundException("Product not found")

    def place_order(self, customer, order_items, shipping_address):
        try:
            # Check if customer exists
            self.cursor.execute("SELECT * FROM customers WHERE customer_id = ?", customer.customer_id)
            if not self.cursor.fetchone():
                raise CustomerNotFoundException("Customer not found")

            order_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Calculate total price
            total_price = sum(product.price * quantity for product, quantity in order_items.items())
            # Insert into orders
            self.cursor.execute("INSERT INTO orders (customer_id, order_date, shipping_address,total_price)" 
                                "OUTPUT INSERTED.order_id " 
                                "VALUES (?, ?, ?,?)",
                                customer.customer_id, order_date, shipping_address,total_price)
            order_row = self.cursor.fetchone()
            

            if not order_row or order_row[0] is None:
                raise OrderNotFoundException("Order ID could not be retrieved.")
            order_id = order_row[0]

            for product, quantity in order_items.items():
                self.cursor.execute(
                    "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)",
                    (order_id, product.product_id, quantity)
                )

            self.conn.commit()
            return True

        except Exception as e:
            print(f"Error placing order: {e}")
            return False

    def get_orders_by_customer(self, customer_id):
        try:
            self.cursor.execute("SELECT * FROM orders WHERE customer_id = ?", customer_id)
            orders = self.cursor.fetchall()

            if not orders:
                raise OrderNotFoundException("No orders found for this customer.")

            order_data = []

            for order in orders:
                order_id = order[0]
                self.cursor.execute("""
                    SELECT p.name, p.price, oi.quantity
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.product_id
                    WHERE oi.order_id = ?
                """, order_id)

                items = self.cursor.fetchall()
                order_items = {}
                for item in items:
                    product = Products(name=item[0], price=item[1])
                    order_items[product] = item[2]

                order_data.append(order_items)

            return order_data
        except Exception as e:
            print(f"Error getting orders: {e}")
            raise OrderNotFoundException("Could not retrieve orders.")
