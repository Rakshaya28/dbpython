import pyodbc

import sys
sys.path.append(r"C:\Users\HP\Documents\Ecom")

from util.DBPropertyUtil import DBPropertyUtil

class DBConnUtil:
    @staticmethod
    def get_connection():
        connection_string = DBPropertyUtil.get_property_string()
        return pyodbc.connect(connection_string)