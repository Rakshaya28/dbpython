import sys
sys.path.append(r"C:\Users\HP\Documents\Ecom")


import pyodbc

driver_name='SQL Server'
server= 'DESKTOP-R30EJB7\SQLEXPRESS' 
database='Ecom'


class DBPropertyUtil:
    @staticmethod
    def get_property_string():
        connection_string = (
            f'Driver={driver_name};'
            f'Server={server};'
            f'Database={database};'
            f'Trusted_Connection=yes;')
        return connection_string