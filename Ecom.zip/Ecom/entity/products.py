class Products:
    def __init__(self, product_id=None, name=None, price=None, description=None, stockQuantity=None):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.description = description
        self.stockQuantity = stockQuantity


    # Getters
    def get_product_id(self):
        return self.product_id

    def get_name(self):
        return self.name

    def get_price(self):
        return self.price

    def get_description(self):
        return self.description

    def get_stockQuantity(self):
        return self.stockQuantity

    # Setters
    def set_name(self, name: str):
        self.name = name

    def set_price(self, price: float):
        self.price = price

    def set_description(self, description: str):
        self.description = description

    def set_stockQuantity(self, stockQuantity: int):
        self.stockQuantity = stockQuantity
